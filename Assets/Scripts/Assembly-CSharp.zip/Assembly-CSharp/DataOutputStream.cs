public class DataOutputStream : myWriter
{
	public sbyte[] toByteArray()
	{
		return getData();
	}
}
