public class MainDialog : AvMain
{
	public int wDia;

	public int hDia;

	public int xDia;

	public int yDia;

	public int numw;

	public int numh;

	public int type;

	public string[] strinfo;

	public override void keypress(int keyCode)
	{
		base.keypress(keyCode);
	}

	public virtual void DoneChat()
	{
	}
}
