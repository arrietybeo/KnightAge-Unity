public class NPCMini
{
	public int ID;

	public int x;

	public int y;

	public int type;

	public NPCMini(int ID, int x, int y)
	{
		this.ID = ID;
		this.x = x;
		this.y = y;
	}
}
