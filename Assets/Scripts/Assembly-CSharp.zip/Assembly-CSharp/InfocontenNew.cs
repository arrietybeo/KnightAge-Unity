public class InfocontenNew
{
	public int idimage;

	public int index;

	public InfocontenNew(int id, int index)
	{
		idimage = id;
		this.index = index;
	}
}
