public interface IKbAction
{
	void perform(string text);
}
