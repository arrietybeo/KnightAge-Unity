public class Animation
{
	public sbyte[] frame;

	public Animation(sbyte[] frame)
	{
		this.frame = frame;
	}
}
