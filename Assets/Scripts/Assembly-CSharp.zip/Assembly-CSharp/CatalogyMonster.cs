public class CatalogyMonster
{
	public int id;

	public int lv;

	public int maxHp;

	public int typeMove;

	public string name;

	public CatalogyMonster(int id, int lv, int maxHp, int typeMove, string name)
	{
		this.id = id;
		this.lv = lv;
		this.maxHp = maxHp;
		this.typeMove = typeMove;
		this.name = name;
	}
}
