public class TouchScreenKeyboard
{
	public static bool hideInput;

	public static bool visible;

	public bool done;

	public bool active;

	public string text;

	public static TouchScreenKeyboard Open(string text, TouchScreenKeyboardType t, bool b1, bool b2, bool type, bool b3, string caption)
	{
		return null;
	}

	public static void Clear()
	{
	}
}
