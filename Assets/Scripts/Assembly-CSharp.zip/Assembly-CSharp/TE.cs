public class TE : T
{
	public TE()
	{
		T.tathieuung = "Effect: OFF";
		T.bathieuung = "Effect: ON";
		T.khac = "Others";
		T.bonguyenlieu = "Place 5 materials and I will upgrade them for you.";
		T.hoprac = "Create";
		T.members = "Members: ";
		T.thoigianconlai = "Time ";
		T.thanhcong = "Upgrade success";
		T.thatbai = "Upgrade fail";
		T.mapName = new string[92]
		{
			"Small Village",
			"Wolf Village",
			"Mines",
			"Edge of the Forest",
			"Fire Cave",
			"Illusion Forest",
			"Canyon",
			"Wolf Prairie",
			"Mysterious Valley",
			"Memory Lake",
			"Empty Zone",
			"Coast",
			"Rock Cliff",
			"Barrier Reef",
			"Shipwreck",
			"Swamp",
			"Ancient Temple",
			"Bat Cave",
			"Devil Wolf Cave",
			"Sea Coast",
			"Desert",
			"Sand Dune",
			"Subsidence Zone",
			"Death Pit",
			"Sandy Graveyard",
			"Dead Forest",
			"Hot Springs",
			"Stone Valley",
			"Guardian Boss",
			"Catacomb Level 1",
			"Catacomb Level 2",
			"Catacomb Level 3",
			"Mummy Boss",
			"City of Gold",
			"West Side",
			"East Side",
			"Arena",
			"Terrace",
			"Mountain Pass",
			"Cliff",
			"Rainbow Mountain",
			"Entrance to Upper World",
			"Narrow Pass",
			"Underground Entrance",
			"Cliff",
			"Entrance to Lower World",
			"Arena",
			"Corpse Hill",
			"Crossroads of death",
			"Phó bản mới",
			"Garden",
			"Heaven Gate",
			"Hell Gate",
			"Equip",
			"Light Village",
			"Equip",
			"Wind Village",
			"Prepare",
			"Lightning Village",
			"Prepare",
			"Fire Village",
			"Battlefield",
			"Hell floors 1",
			"Forest medusa",
			"Forest Chimera",
			"Forest monsters",
			"Waterfall",
			"Harbor Town",
			"Area south shore",
			"Area north shore",
			"Area west coast",
			"forest mouse",
			"red flower Forest",
			"Gulf Caribe ",
			"Maze",
			"Maze Floor 1",
			"Maze Floor 2",
			"Maze Floor 3",
			"Maze Floor 4",
			"Maze Final Floor",
			"PK",
			string.Empty,
			"Marketplace",
			"East Door",
			"West Door",
			"South Door",
			"North Door",
			"Arena",
			"Map 88",
			"Map 89",
			"Map 90",
			"Map 91"
		};
		T.hiennguoichoi = "Show other players";
		T.hoihienguoichoi = "Do you want show other players";
		T.hoiannguoichoi = "Do you want hide other players";
		T.annguoichoi = "Hide other players";
		T.trangbi1 = "Equipment 1";
		T.trangbi2 = "Equipment 2";
		T.quaylai = "return";
		T.can_not_move = "You can not move when you are selling.  Do you want to stop selling?";
		T.nhapSlogan = "Enter Shop Name";
		T.hoanthanh = "Complete";
		T.nhapsai = "Error.  Please re-enter.";
		T.hoidaugia = "You want to sell: ";
		T.nhapgiaban = "Enter price";
		T.daugia = "Sell";
		T.gianHang = "Store";
		T.NghiBan = "Stop Selling";
		T.TimeThachDau = "Challenge begins after: ";
		T.chuaboduclo = "Let's put your mystery chisel and your item, after that I will chisel for you a hole";
		T.DucLo = "Made Hole";
		T.muaNhieu = "Buy more";
		T.bongoc = "Put gem on, and I will graft gem for you";
		T.hopngoc = "Mix gem";
		T.hetNgoc = "you have run of out this gems, let's go out and kill monsters to collect gems and bring them back to me";
		T.khongbothem = "can not add anymore";
		T.chuaboitem = "Please put your weapons, i will mix gem for you";
		T.bovao = "Put in";
		T.khamNgoc = "Add gem";
		T.khongcongua = "You not have mount in inventory.";
		T.Logifail = "Connect failure, please check your internet connection.";
		T.Tips = "Tips: ";
		T.mTips = new string[13]
		{
			"Hold chat button in 2s, it will open the quick chat menu.", "Lucky boxes are appear randomly every 1 hour in map.", "One guild can own more than one mine.", "Hunting monsters and challenges another knight will gain fame.", "Fame will decline if knight inactive for some time.", "Complete dungeon can earn Pet eggs.", "Register arena at Mr. Ballard in Fire Cave.", "Boss will reborn after 12 hour.", "Enhance item will randomly get bone.", "Ghost will appear after Knight reached level 20.",
			"Health point can be restored when standing still or using food.", "Can join Zone(2h) for free with Tyche coin.", "In Zone(2h), drop rates and experience will be higher other zone."
		};
		T.mQuickChat = new string[20]
		{
			"Hi!", "muahahaha!!!", "Wait for me a bit!", "Noob!", "Pro!", "Too lag!", "Party?", "Everyone gathers", "Let's go", "Let's invaded mine!",
			"Let's hunt boss!", "Who killed me!", "Too crowded!", "Do you want PK?", "Please invite me to guild!", "Recruiting members!", "Go to bed", "Bye!", "dangerous! Run", "Help me!!!"
		};
		T.TchangSv = "You've to change to Global Server. Please, use another account to login";
		T.TuseNgua = "Mounts";
		T.TisNguaNau = "Can't attack on horse!";
		T.speedUp = "Speed up";
		T.textXuongNgua = "Off the horse";
		T.textHoiXuongNgua = "Horses will be lost when off the horse, you do want to off the horse ?";
		T.infoArena = "Battlefield information";
		T.backBattlefield = "Join battlefield after: ";
		T.yes = "Yes";
		T.no = "No";
		T.choimoi = "New Game";
		T.choi_daco_TK = "Continue";
		T.daco_TK = "Sign In";
		T.doi_TK_khac = "Change Account";
		T.minutes = "minutes";
		T.changeScrennSmall = "Low Resolution";
		T.normalScreen = "High Resolution";
		T.changeSizeScreen = "Game must be restarted to change resolution, Proceed ? ";
		T.del = "Delete";
		T.username = "Username";
		T.password = "Password";
		T.login = "Login";
		T.menu = "Menu";
		T.select = "Select";
		T.close = "Close";
		T.waitLogin = "Logging, Please wait...";
		T.nulluserpass = "Please select your character.";
		T.next = "Next";
		T.server = "Server";
		T.create = "Create";
		T.level = "Level ";
		T.Lv = "Lv";
		T.namePlayer = "Character Name";
		T.nameMin6char = "Name must have at least 6 characters.";
		T.back = "Back";
		T.remember = "Remember";
		T.hotKey = "Hotkey";
		T.congdiem = "Add point";
		T.phim = "Key";
		T.giaotiep = "Chat";
		T.createChar = "Create New";
		T.buy = "Buy";
		T.diemtiemnang = "Attribute points: ";
		T.diemkynang = "Skill points: ";
		T.nhanvat = "Character: ";
		T.mainQuest = "Main task";
		T.subQuest = "Sub task";
		T.viewMap = "Map";
		T.nhan = "Receive";
		T.tra = "Completed";
		T.cancel = "Cancel";
		T.quest = "Quest";
		T.chat = "Chat";
		T.noMessage = "No messages";
		T.delTabChat = "Close tab";
		T.read = "Read";
		T.view = "View";
		T.change = "Change";
		T.equip = "Equipment";
		T.setPoint = "Add point";
		T.cong = "Add";
		T.danglaydulieu = "Loading..";
		T.hoihuyQuest = "Do you want to quit this quest?";
		T.hoiBuy = "Do you want to buy ";
		T.pleaseWait = "Please wait";
		T.leftRing = "Left ring";
		T.rightRing = "Right ring";
		T.hoiDelItem = "Do you want to drop this item ?";
		T.nhapsoluongcanmua = "Enter quantity you want to buy:";
		T.khongcovatphanphuhop = "Inventory does not have appropriate item.";
		T.cong1diem = "Do you want to add 1 point ?";
		T.nhapsodiem = "Enter number of points to ";
		T.nhohonhoacbang = "less than or equal ";
		T.cong1kynang = "Do you want to add 1 skill point?";
		T.setKey = "Set Hotkey";
		T.nhatdcvatpham = "pick up an item";
		T.farfocus = "This target is so far away";
		T.party = "Group";
		T.noParty = "You do not have any Group close by";
		T.invite = "Invite";
		T.mainLeave = "Kicked out from Group";
		T.leave = "Leaving";
		T.mainCancle = "The Group disbanded";
		T.addFriend = "Add friend";
		T.nullParty = "You don't have Group";
		T.gianhap = "Join";
		T.lapnhom = "Create Group";
		T.khacclass = "You can not use this item.";
		T.listParty = "Group Member List";
		T.buySell = "Trade";
		T.khoa = "Lock";
		T.fullBuySell = "Max of 9 items per trade";
		T.kynangchuass = "Skill points are not ready";
		T.price = "Price";
		T.deleteFriend = "Do you want to delete this person from Friend List?";
		T.beginChat = "Start to talk with";
		T.listFriend = "Friend List";
		T.nullFriend = "Make more friends !";
		T.hoivaonhom = "Do you want to join this Group?";
		T.hoilapnhom = "Do you want to create a Group?";
		T.item = "item";
		T.dungitem = "Do you want to use this item?";
		T.use = "Use";
		T.underlevel = "To use this item, you must reach lvl.";
		T.chuahoc = "Haven't learn this skill yet.";
		T.yeucau = "Require";
		T.nangluong = "Mana cost ";
		T.delay = "Time remain: ";
		T.timebuff = "Time buff: ";
		T.hieuung = "Effect: ";
		T.timehieuung = "Buff duration: ";
		T.tanghpdung = "HP increase: ";
		T.tangmpdung = "MP increase: ";
		T.phamvi = "Range: ";
		T.phamvilan = "Area of Effect: ";
		T.somuctieu = "Number of targets: ";
		T.banthan = "Myself";
		T.moinguoi = "Every body";
		T.trongdoi = "In Group";
		T.kethu = "Enemy";
		T.buff = "Buff";
		T.active = "Attack";
		T.passive = "Passive";
		T.kynang = "Skill ";
		T.velang = "Go Back";
		T.muonvelang = "Do you want to revive instantly?";
		T.sell = "Sell";
		T.hoisell = "Do you want to sell ";
		T.LVyeucau = "Required Level: ";
		T.yeucauketban = " wants to be your friend?";
		T.chapnhan = "Accept";
		T.tuchoi = "Deny";
		T.myseft = "Inventory";
		T.info = "Info";
		T.trochuyen = "Chat";
		T.moiParty = "Invite to Group";
		T.vucbo = "Drop Item";
		T.coin = "gold";
		T.gem = "gem";
		T.hoithoat = "Do you want to exit ?";
		T.exit = "Exit";
		T.dangdangnhap = "Connecting to sever. Please wait.";
		T.hoiFrist = "Have you ever played or owned Knight Online account before? ";
		T.oldPlayer = "Yes";
		T.newPlayer = "No";
		T.register = "Register";
		T.help = "Help";
		T.clearData = "Clear Data";
		T.lienhe = "Would you like to reset your Password in Website?";
		T.dacotaikhoan = "Already have an account";
		T.dagoidangky = "Information send. Please wait a few minutes.";
		T.quenpass = "Forgot Password";
		T.thulai = "Server Timeout. Please try again.";
		T.texthelpRegister = "Enter your account and password to register";
		T.lostMana = "Not enough energy.";
		T.capdochuadu = "Your level is not enough";
		T.nhandc = " You receive:";
		T.diemcongvao = "Extra point ";
		T.hoisinh = "Revive";
		T.newParty = "Create new Group";
		T.oso = string.Empty;
		T.loimoiParty = "Do you want to invite your friend to your Group. OK?";
		T.moikhoinhom = "You have been kicked out of Group.";
		T.giaitannhom = "Your Group has been disbanded.";
		T.roikhoinhom = "You have left the Group.";
		T.vuataonhom = "Your Group has been created successfully.";
		T.disconnect = "No server connection. Please try again.";
		T.hoigiaodich = " wants to trade with you. Do you agree?";
		T.huygiaodich = "Your trade has been canceled.";
		T.khongthegiaodich = "You cannot trade quest items";
		T.chuyentien = "Transfer";
		T.nhapsotien = "Enter the money you want to trade(lesser or equal 10 million):";
		T.xacnhan = "Confirm";
		T.giaodichthanhcong = "Transaction is completed.";
		T.giatrinhapsai = "Not enough money to complete.";
		T.banmuongiaodich = "Did you check and want to trade?";
		T.xincho = "Please wait";
		T.setPk = "Change Flag";
		T.dosat = "PK";
		T.on = "Enable ";
		T.off = "Disable ";
		T.hut = "avoid attack";
		T.voigia = "Price: ";
		T.la = "is";
		T.tinden = "Inbox";
		T.khongthecong = "The maximum points you can add is ";
		T.changeArea = "Change Zone";
		T.Area = "Zone ";
		T.nhapsdt = "Enter your account";
		T.trora = "Back";
		T.tinnhan = "Message";
		T.friend = "Friend";
		T.logout = "Log out";
		T.autoHP = "Auto use HP/MP";
		T.auto = "Auto Functions";
		T.autoFire = "Auto Attack";
		T.timduongtoilang = "Go to White Wolf village as your mother requested";
		T.again = "Retry";
		T.nhanNv = "Accept";
		T.traNv = "Report";
		T.tacdunglen = "Have effect on";
		T.mucdohoanthanh = "Level of accomplishment";
		T.khongthetraodoi = "Cannot trade this item !";
		T.xinchogiaodich = "Please wait for trade ";
		T.xacnhangiaodich = "Trade confirmation";
		T.chuyensang = "Move to";
		T.keypad = "keypad";
		T.touch = "touch";
		T.Ring = "Ring";
		T.menuChinh = "MENU";
		T.chucnang = "Function";
		T.khuvuc = "Zone";
		T.chimang = "Critical: ";
		T.tatcasatthuong = "All damages: ";
		T.satthuongvatly = "Physical damage: ";
		T.satthuonglua = " Fire damage: ";
		T.satthuongdoc = " Poison damage: ";
		T.satthuongdien = "Lightning damage: ";
		T.nedon = "Evade: ";
		T.phongthu = "Defense: ";
		T.hoihelp = "Would you like to process Tutorial for Beginners? You also can turn off the tips by clicking Menu > Function > Turn of Tutorial";
		T.endHelp = "Turn off Tutorial";
		T.dangketnoilai = "Reconnecting, please wait.";
		T.vetruoc = "Back home ";
		T.toitruoc = "Next page ";
		T.listnull = "No one in the list";
		T.suckhoe = "Stamina: ";
		T.yeusuckhoe = "Not enough Stamina !";
		T.tabhanhtrang = "Inventory";
		T.tabtrangbi = "Equipment";
		T.tabthongtin = "Character";
		T.tabkynang = "Skill Tree";
		T.tabnhiemvu = "Quest";
		T.tabhethong = "Settings";
		T.tabchucnang = "Functions";
		T.strhelp = "-Control Keys\n  + Use Arrow Keys or Num 2,4,6,8 to move.\n  + Num 5 (or Select Key),1,3,7,9 to use hot keys like Attack skills and Potions\n+ Use * key to open Chat tab, use num 0 to switch Hot key Skill tab.\n-NPC\n  +You can buy Potion (HP, MP…) in Lisa & Emma's Shop.\n  +Buy armor in Doubar & Alisama's Shop.\n  +Buy weapons in Hammer & Black Eye.\n  +Teleport Stone: travel between maps in game.\n  +Store your items at Aman & Amin.\n  +Zulu: you can change your hair style in Hair Shop and accept daily quest.\n  +Wizard: upgrade your equipment and provides materials.\n  +Zoro & Benjamin: create your Guild, provide some items in Guild.\n  +Commander: accept  your side quests.\n  +God of Wings: creates and upgrades your wings.\n\n\n           Knight Online\n  Development: Silver Shield Studio (VN)\n  Sound by www.freesound.org\n  Music by audionautix.com\n  Thanks for playing game!";
		T.noichuyen = "Chat";
		T.download = "Download";
		T.dcchimang = "Critical";
		T.dcxuyengiap = "Pierce Attack ";
		T.mau = "HP: ";
		T.khangtatcast = "Evade all damage: ";
		T.xuyengiap = "Pierce Attack: ";
		T.nangluong = "Mana: ";
		T.satthuongbang = "Ice damage: ";
		T.phansatthuong = "Reflect Damage: ";
		T.giet = "Kill ";
		T.nhat = "loot";
		T.autoItem = "Auto Loot";
		T.fullInven = "Full Inventory";
		T.helpCapchar = "Click on the right numbers to kill the ghost!";
		T.cauhinhthap = "Low Graphics";
		T.naptien = "Purchase";
		T.dangdungtocnay = "This item is already equipped.";
		T.dasohuu = "Purchased";
		T.chapnhanketban = " has accepted your friend request.";
		T.hang = "Rank";
		T.chuanhapsdt = "Please enter your email address.";
		T.chuanhapmk = "Please enter your password.";
		T.sdtkhople = "Phone number is not valid. (Example: 0912345678 or 84918765432)";
		T.emailkhople = "Email address is not valid. (Example: nickname@yahoo.com or nickname@gmail.com)";
		T.kiemtralai = "Please check your information again, you may use this to recover your password.";
		T.sdt = "Mobile phone number: ";
		T.email = "Email address: ";
		T.nangcapyeucau = "Upgrade required: Lv ";
		T.thongbaotuserver = "Notification from server";
		T.khongganmauvaophimnay = "The item cannot place in this hotkey.";
		T.questitem = "Quest item";
		T.layra = "To Inventory";
		T.catvao = "To Storage";
		T.nhapsoluongcanlay = "Please enter a number:";
		T.nhapsoluongcancat = "Please enter a number:";
		T.sellmore = "Sell all";
		T.banhetxanh = "Sell all blue items";
		T.banhettrang = "Sell all non-magic items";
		T.khongconxanh = "No blue items found.";
		T.khongcontrang = "No non-magic items found.";
		T.dotrang = " non-magic item.";
		T.doxanh = " blue item.";
		T.chiphi = "Cost: ";
		T.nguyenlieu = "Materials:";
		T.tilemayman = "Lucky chance:";
		T.hoac = " or ";
		T.dapdo = "Upgrade";
		T.hoidapxuluong = "Do you want to upgrade item with ";
		T.hay = " or ";
		T.setting = "Settings";
		T.bovatphamvao = "Chose an item you want to upgrade, I will help you.";
		T.dapbangxu = "Do you want to upgrade this item with ";
		T.chest = "Storage Chests";
		T.namenaptien = "Buy Gems";
		T.trochuyenvoi = "Speak to ";
		T.noEvent = "Empty list";
		T.mevent = "Notifications";
		T.loimoikb = "Friend Request.";
		T.moivaoParty = "Invite to Join their Group.";
		T.loimoigiaodich = "Trade Request.";
		T.thachdau = "PvP";
		T.loimoithachdau = "Challenge you in PvP.";
		T.autoBuff = "Auto Buff";
		T.thongbao = "Notify";
		T.hoichoniconclan = "Accept this as your Guild Icon?";
		T.iconclan = "Guild Icon";
		T.contentclan = "Unique icon for Guilds.";
		T.showAuto = " Show Info";
		T.addmemclan = "Invite to Guild";
		T.moivaoclan = " invite to join their Guild.";
		T.loimoivaoclan = "Guild Request.";
		T.clan = "Guild";
		T.bieutuong = "Icon: ";
		T.chuakhauhieu = "Slogan doesn't have.";
		T.xinvaoclan = "Ask to join Guild";
		T.xemdanhsach = "Member List";
		T.gop = "Contribute ";
		T.nhapsoxumuongop = "Please enter number of Gold you want to contribute to Guild:";
		T.nhapsoluongmuongop = "Please enter number of Gems you want to contribute to Guild:";
		T.doiSlogan = "Change Slogan";
		T.doiNoiquy = "Change Rules";
		T.phonghacap = "Promote/Downgrade";
		T.nhapthongtindoi = "Please enter the info you want to change:";
		T.slogan = "Slogan";
		T.noiquy = "Rules";
		T.thanhvien = "Members";
		T.chucvu = "Rank: ";
		T.moiroiclan = "Remove from Guild";
		T.roiclan = "Leave Guild";
		T.tabThuLinh = "Guild Leader";
		T.tabBangHoi = "Guild";
		T.chattoanbang = "Guild Chat";
		T.doithongbao = "Changes Notification";
		T.bankhongconclan = "You are not in Guild.";
		T.soluong = "Gems: ";
		T.donggopclan = "Contributes to Guild";
		T.quyxu = "Gold Fund: ";
		T.quyngoc = "Gems Fund: ";
		T.hoibatdosat = "Do you want to enable PK mode?";
		T.update = "Update List";
		T.minimap = "Mini Map";
		T.textkenhthegioi = "World Chat";
		T.text2kenhthegioi = "World Channel - ";
		T.kenhthegioi = "Do you want to chat in World Channel ";
		T.noidungnhusau = " with the following content:";
		T.nhapnoidung = "Enter the content";
		T.chatParty = "Group Chat";
		T.phi = "Cost ";
		T.replace = "Transfer Items";
		T.hoichuyendo = "Do you want to transfer level upgrading of ";
		T.qua = " to ";
		T.dochuyen = "Item use to transfer: ";
		T.donhan = "Ouput Item: ";
		T.plusnhanduoc = "The result of Transfer:";
		T.boitemreplace = "Please select 2 items you want to Transfer. I will cast a spell on them.";
		T.nhanban = "clone";
		T.khongconhiemvu = "No new Quest";
		T.timeyeucau = "Upgrading Time: ";
		T.taoCanh = "Create Wings";
		T.hoiTaoCanh = "Would you like to create ";
		T.Lvsudung = "Level required ";
		T.nangcap = "Upgrade";
		T.sudungsau = "Can be used after ";
		T.phandon = "Reflect";
		T.hoiroiClan = "Do you want to leave Guild?";
		T.updateData = "Data is downloading, Please wait a moment.";
		T.updateok = "Download Data completed.";
		T.hoinangcapcanh = "Would you like to upgrade ";
		T.listserver = "Select Server";
		T.SetMusic = "Sound Settings";
		T.maychu = "Server ";
		T.tuoi = "Age: ";
		T.tancong = "Attack: ";
		T.choan = "Feed";
		T.lockMap = "World Map Function is blocking.";
		T.delMess = "Delete message";
		T.khongthedung = "Cannot be used. ";
		T.about = "About";
		T.textabout1 = "Knight Age Online\nVersion: ";
		T.textabout2 = "Silver Bat Studio (VN)\nSound by www.freesound.org\nMusic by audionautix.com\nFor Help: knight.online.ssvn@gmail.com";
		T.nokiaprivacy = "Privacy";
		T.thoigianaptrung = "Elapsed time ";
		T.aptrung = "Hatch";
		T.nhaptaikhoan = "Username (if available)";
		T.choi = "Play";
		T.moly = "Lottery";
		T.startdraw = "Start";
		T.choitiep = "Redraw";
		T.chonlai = "Reselect";
		T.hopNguyenLieu = "Placed five materials of the same type, I will help you.";
		T.hopThanh = "Combine";
		T.YOUNEED = "You must have";
		T.mhang = new string[4] { "I", "II", "III", "IV" };
		T.mChucVuClan = new string[7] { "Leader", "Deputy Leader", "Great Knight", "Noble Knight", "Knights of Honor", "New Members", "has left the Guild" };
		T.mVolume = new string[2] { "Background Music: ", "Sound: " };
		T.textCreateChar = new string[4] { "Class", "Hair", "Eye", "Head" };
		T.mClass = new string[4] { "Warrior", "Assassin", "Sorcerer", "Gunner" };
		T.mCreateChar_HAIR = new string[2][]
		{
			new string[2] { "Straw", "Dust" },
			new string[2] { "Long", "Short" }
		};
		T.mCreateChar_EYE_FACE = new string[2][]
		{
			new string[4] { "Black", "Blue", "Black", "Blue" },
			new string[2] { "Normal", "Elf" }
		};
		T.mKyNang = new string[4] { "Strength", "Dexterity", "Vitality", "Intelligent" };
		T.story = new string[3] { "Over 500 years ago, this great land served as a battleground between two great armies from two ancient kingdoms. At that time, everyone lived in fear as horrific monsters arose. The war eventually ended, but left great hardship as the struggling survivors tried to rebuild the peace.", "The Fellowship of Knights was created to protect the land and people. Stories of great bravery and heroism spread, and it soon became the dream of every young child to grow up and become a great knight.", "You are becoming a young adult, and it is time for you to accept this challenge and prove you are ready to join the Fellowship of Knights." };
		T.mColorPk = new string[10] { " Take off flag ", "Red", "Green", "Blue", "Purple", "Yellow", "Orange", "Pink", "Blue", "Black" };
		T.mAuto = new string[2] { "Use HP potion when HP is lower than ", "Use HP potion when MP is lower than" };
		T.mUtien = new string[2] { "Priority: < small to large >", " Priority: < small to large >" };
		T.mAutoItem = new string[3] { "Items ", "MP,HP ", "Gold " };
		T.mValueAutoItem = new string[3][]
		{
			new string[6] { "Loot all", "Loot from blue items", "Loot from yellow items", "Loot from purple items", "Loot from orange items", "Do not want to loot " },
			new string[4] { "Loot all", "Only loot HP", "Only loot MP", "Do not loot" },
			new string[2] { "Loot", "Do no want to loot" }
		};
		T.helpMenu = new string[1] { "Click here" };
		T.mQuest = new string[2] { "Processing", "Completed" };
		T.mHelp = new string[10][]
		{
			new string[5] { "Welcome to the world of the Knight Online.", "This is the instrucions for newbie. ", "Press key 2 to go up, key 8 to down, key 4 to left and  key 6 to right.", "You also can use arrows to move easier.", "Please move to the yellow position on the screen. " },
			new string[10]
			{
				" Good, next you can use key 5 to hit a monster.",
				" The arrow above is the sign to show that where you aim to ",
				string.Empty,
				"Kill one monster is so easy. When you hit the monster you will receive some experience.",
				" You also can pick up more items. Now try to hit a few monsters to verify.",
				string.Empty,
				"The items you picked will be put into your inventory",
				"Go to your inventory to see what we have in it.",
				"To do this, left click and choose Inventory - Character .",
				"Left click and choose Inventory - Character "
			},
			new string[13]
			{
				"This is inventory where you can put everything in it. ", "Currently, you have several healing potion, mana potion and 1 pair of shoes. ", "Try to use healing potion by moving white frame to healing potion. ", "Left click and use ", "Click and use", "Very good, there is another way for you to use healing and mana potion by set up short cut in order to action more quicker. ", "You can use HOT KEY to act faster.", "Move cursor to healing potion and choose it again.", "Use HOT KEY this time and choose one which key you are familiar with.", "Choose and click on HOT KEY.",
				"Click on Choose and select HOT KEY. ", "Do it the same for using keybiindings to mana potion. ", "Try to use HOT KEY when needed."
			},
			new string[9] { "There are a pair of shoes in your inventory.", "Besides making you look pretty, they will also make you stronger.", "Equipping them will increase your health. ", "Try to equip them now.", "Click Choose and select Use. ", "So simple, right? ", "Whatever you equip, will appear in Inventory. ", "Select inventory to see what you have. ", "Move your cursor here." },
			new string[10] { "Character information helps you know which clothes you are wearing.", "The left side shows character and your rate resistance to effect", "The right side shows attack power and defense.", "This is what you are wearing.", "When you want to equip an item in your inventory. ", "Choose the slot you want and change your item. ", "It is also a great way to compare the power of different items.", "Try this function when you find new loot.", "Now get back to your adventure.", "Right click to exit." },
			new string[8]
			{
				string.Empty,
				"The mini map gives a bigger view of where you are.",
				"Pay attention to the blinking yellow spot because that is where you need to go.",
				"This is the info of your health, mana and level.",
				"When you choose any target, there info will appear here.",
				"If you want to change the target, just left left click.",
				"You have 2 action bars, use 0 to change. ",
				"Click * to chat with people nearby."
			},
			new string[3] { "Level Up.There are many interesting things that you need to know.", "Click Inventory - Character.", " Left click and choose Inventory - Character." },
			new string[10] { "Character screen tell you everything about you. ", "You will see 4 attributes:  strength, dexterity, vitality & intelligence ", "Every time you level up, you will earn 1 extra point.", "You will also get 5 points to add to your character as you like.", "Look at your character info to see the difference.", "Try to add points into health section to see the change.", "Move here and click Choose.", "Very good.  Now see how your index increased.", "When you level up, your skills will also increase.", "Move cursor to here to see." },
			new string[11]
			{
				"Skills show all the new powers you can learn.",
				"Active skills are on the left. ",
				"The first column shows physical skills and the second column show magic. ",
				"Passive and Buff skills are on the right. ",
				"Every time level up will give you 1 free skill point.",
				"You can put it on any skill you think is best for you.",
				"You can reset all skill point by using Special Potion from Shop.",
				"Just select a skill and click Add point.",
				"Like before, you can also use HOT KEY to act faster.",
				"Use HOT KEY to any button and go back to check strength.",
				string.Empty
			},
			new string[8]
			{
				"You have just received a new quest, go to Inventory - Character to check quest details.",
				"Move cursor here ",
				"This is menu is your quest log ",
				"The left tab shows quests you are doing.",
				"The right tab shows completed quests wanting you to return to the person asking you for help. ",
				"Just click on any quest and then SEE, for more details.",
				"Remember to use the map to show you where you need to go.",
				string.Empty
			}
		};
		T.mHelpPoint = new string[10][]
		{
			new string[5]
			{
				string.Empty,
				string.Empty,
				"Use the on-screen arrows to move. ",
				"Or click the place on the screen to move there. ",
				string.Empty
			},
			new string[10]
			{
				"Good, now click on a monster to kill it.",
				string.Empty,
				string.Empty,
				string.Empty,
				string.Empty,
				string.Empty,
				string.Empty,
				string.Empty,
				"Choose Menu - Inventory - Character..",
				"Click here and choose Inventory - Character. "
			},
			new string[13]
			{
				string.Empty,
				string.Empty,
				"Click healing potion. ",
				"Click again and use it. ",
				"Click here and use. ",
				string.Empty,
				string.Empty,
				"Choose healing potion again. ",
				string.Empty,
				"Click here and choose HOT KEY. ",
				"Click here and choose HOT KEY. ",
				string.Empty,
				string.Empty
			},
			new string[9]
			{
				string.Empty,
				string.Empty,
				string.Empty,
				string.Empty,
				"Click here and use. ",
				string.Empty,
				string.Empty,
				string.Empty,
				"Click here to open inventory. "
			},
			new string[10]
			{
				string.Empty,
				string.Empty,
				string.Empty,
				string.Empty,
				string.Empty,
				string.Empty,
				string.Empty,
				string.Empty,
				string.Empty,
				"Click here to come back. "
			},
			new string[9]
			{
				string.Empty,
				" The mini-map gives you a bigger view of where you are. ",
				" Pay attention to the blinking yellow spot because that is where you need to go.",
				string.Empty,
				string.Empty,
				" When you choose any target, their info will appear here.",
				" To change the target, just touch here.",
				" You have 2 action bars, touch here to change.",
				" Click here to chat with nearby players."
			},
			new string[3]
			{
				string.Empty,
				string.Empty,
				" Click here to choose Inventory - Character."
			},
			new string[10]
			{
				string.Empty,
				string.Empty,
				string.Empty,
				string.Empty,
				string.Empty,
				string.Empty,
				"Click here to add points.",
				string.Empty,
				string.Empty,
				" Click here to add skill points "
			},
			new string[11]
			{
				string.Empty,
				string.Empty,
				string.Empty,
				string.Empty,
				string.Empty,
				string.Empty,
				string.Empty,
				"Choose one skill and add points",
				string.Empty,
				string.Empty,
				string.Empty
			},
			new string[8]
			{
				string.Empty,
				"Click here to open Quest.",
				string.Empty,
				string.Empty,
				string.Empty,
				"When you want to know more about any quest, just click here.",
				string.Empty,
				string.Empty
			}
		};
	}
}
