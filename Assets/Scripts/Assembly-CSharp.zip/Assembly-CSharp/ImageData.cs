public class ImageData
{
	public mImage img;

	public short id;

	public string path = string.Empty;

	public int timeRemove;

	public int timeLimit;

	public bool isLoad;

	public long timeGetBack;
}
